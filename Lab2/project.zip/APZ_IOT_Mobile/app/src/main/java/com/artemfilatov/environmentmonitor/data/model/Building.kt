package com.artemfilatov.environmentmonitor.data.model

data class Building(
    val id: String,
    val name: String,
    val address: String
)
