package com.artemfilatov.environmentmonitor.data.model

data class Office(
    val id: Int,
    val name: String,
    val buildingId: Int
)